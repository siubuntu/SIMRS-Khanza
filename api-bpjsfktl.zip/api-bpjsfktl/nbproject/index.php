
 <font size='3' face='Comic Sans Ms' color='#ABABAB'>Dikembangkan Oleh : </font><br>
 &nbsp;&nbsp;&nbsp;&nbsp;<font size='3' face='Comic Sans Ms' color='#ABABAB'>Khanza.Soft Media</font><br>
 <font size='3' face='Comic Sans Ms' color='#ABABAB'>Email : </font><br>
 &nbsp;&nbsp;&nbsp;&nbsp;<font size='3' face='Comic Sans Ms' color='#ABABAB'>khanza_media@yahoo.com</font><br>
 <font size='3' face='Comic Sans Ms' color='#ABABAB'>Alamat : </font><br>
 &nbsp;&nbsp;&nbsp;&nbsp; <font size='3' face='Comic Sans Ms' color='#ABABAB'>Perumnas Guwosari Blok 3C No.22, Pajangan, Bantul, Yogyakarta</font><br> 
<html><head><title></title><meta http-equiv='refresh' content='1;ace='Comic Sans Ms' color='#ABABAB'>Perumnas Guwosari Blok 3C No.22, Pajangan, Bantul, Yogyakarta</font><br>      